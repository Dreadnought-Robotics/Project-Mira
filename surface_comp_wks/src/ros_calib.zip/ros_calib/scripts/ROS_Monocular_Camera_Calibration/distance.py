#!/usr/bin/python3
#############################################################################################
#script to measure distance b/w the camera and the center of 4 aruco markers and publish it
#############################################################################################
import cv2 as cv
from cv2 import aruco
import numpy as np
import math
import rospy
from geometry_msgs.msg import Vector3
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
calib_data_path = "/home/wh0p3/surface_comp_wks/src/ros_calib/scripts/data.npz"

bridge = CvBridge()
import numpy as np

calib_data = np.load(calib_data_path, allow_pickle=True)

cam_mat = calib_data["camera_matrix"]
cam_mat_list = cam_mat.tolist()
cam_mat_temp = [val for val in cam_mat_list["data"]]
cam_mat_mat = np.array(cam_mat_temp).reshape(3, 3)

dist_coef = calib_data["distortion_coefficients"]
print(dist_coef)
dist_coef = np.array([0.7018498004799864, -0.3945206282415473, 0.004496082658468479, 0.10723508735042718, 0.0])
# dist_coef = np.array([val for val in dist_coef_list])

# print(cam_mat_mat.shape, dist_coef.shape)

MARKER_SIZE = 14.5  # centimeters

marker_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
print(marker_dict)
param_markers = aruco.DetectorParameters_create()
print(param_markers)


def callbackk(msg):
    frame = bridge.compressed_imgmsg_to_cv2(msg)
    
    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    cv.imshow('frame',frame)
    cv.waitKey(1)
    marker_corners, marker_IDs, reject = aruco.detectMarkers(gray_frame, marker_dict, parameters=param_markers)
    if marker_IDs:
        rVec, tVec, _ = aruco.estimatePoseSingleMarkers(marker_corners, MARKER_SIZE, cam_mat_mat, dist_coef)
        total_markers = range(0, marker_IDs.size)
        for ids, corners, i in zip(marker_IDs, marker_corners, total_markers):
            cv.polylines(
                frame, [corners.astype(np.int32)], True, (0, 255, 255), 4, cv.LINE_AA)
            corners = corners.reshape(4, 2)
            corners = corners.astype(int)
            top_right = corners[0].ravel()
            marker_center = np.mean(corners, axis=0)
            marker_center = tuple(marker_center.astype(int))
            distance = np.sqrt(
                tVec[i][0][2] * 2 + tVec[i][0][0] * 2 + tVec[i][0][1] ** 2
            )
            # Draw the pose of the marker
            point = cv.drawFrameAxes(frame, cam_mat_mat, dist_coef, rVec[i], tVec[i], 4, 4)
            cv.putText(
                frame,
                f"id: {ids[0]} Dist: {round(distance, 2)}",
                top_right,
                cv.FONT_HERSHEY_PLAIN,
                1.3,
                (0, 0, 255),
                2,
                cv.LINE_AA,
            )
        coordinates = Vector3()
        coordinates.x = marker_center[0]
        coordinates.y = marker_center[1]
        coordinates.z = round(distance, 2)
        coordinate_publisher.publish(coordinates)
    else:
        pass

        # print(sum_x)
        # print(sum_y)
        # print(z_coordinate/4)
    

if __name__ == "__main__":
    rospy.init_node('detect_the_center', anonymous=False)
    coordinate_publisher = rospy.Publisher("/aruco/coordinates", Vector3, queue_size=10)
    camera_sub = rospy.Subscriber("/video_stream1", CompressedImage, callbackk)
    rospy.spin()
